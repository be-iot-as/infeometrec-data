.. module:: vex

.. _vex:

Vex
=====

.. automodule:: ehtim.vex
    :members:

