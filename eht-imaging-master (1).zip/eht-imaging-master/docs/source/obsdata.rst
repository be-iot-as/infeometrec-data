.. module:: obsdata

.. _obsdata:

Obsdata
=======

.. automodule:: ehtim.obsdata
    :members:

