.. module:: array

.. _array:

Array
=====

.. automodule:: ehtim.array
    :members:

