.. module:: imager

.. _imager:

Imager
===============

.. autofunction:: ehtim.imaging.imager_utils.imager_func

.. automodule:: ehtim.imager
    :members:


