.. module:: movie

.. _movie:

Movie
=====

.. automodule:: ehtim.movie
    :members:

