"""
.. module:: ehtim.tests
    :platform: Unix
    :synopsis: EHT Imaging Utilities: unit tests

.. moduleauthor:: Chi-kwan Chan (chanc@email.arizona.edu)

"""
from . import test_io
