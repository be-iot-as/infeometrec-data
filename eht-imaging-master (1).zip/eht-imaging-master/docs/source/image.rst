.. module:: image

.. _image:

Image
=====

.. automodule:: ehtim.image
    :members:

